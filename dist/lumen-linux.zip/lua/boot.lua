-- boot: load the LuaTools backend behind the shims, then run the injector loop.
--
-- The LuaTools plugin backend is OPTIONAL. A `--noplugin` install ships only the
-- runtime stack (slsteam-moon + Lumen) and Lumen's OWN settings menu (the full-
-- moon button: slsteam-moon config, Game Updates / manifest pins, About), with
-- no LuaTools frontend and no plugin backend on disk. So load the backend only
-- when it's actually present; when it isn't, run in "settings-menu only" mode
-- instead of aborting the whole sidecar (an unguarded dofile of a missing
-- main.lua used to kill Lumen at boot, taking the menu down with it).
local backend = os.getenv("LUMEN_BACKEND_DIR") or ""
local have_plugin = false
local lifecycle

if backend ~= "" then
  package.path = backend .. "/?.lua;" .. package.path
  local main_lua = backend .. "/main.lua"
  local probe = io.open(main_lua, "r")
  if probe then
    probe:close()
    -- Loading main.lua defines the global RPC functions (InitApis, etc.) and
    -- returns a lifecycle table { on_load, on_unload, on_frontend_loaded }.
    local ok, result = pcall(dofile, main_lua)
    if ok then
      have_plugin = true
      lifecycle = result
    else
      io.stderr:write("[lumen] plugin backend failed to load; settings-menu only: "
        .. tostring(result) .. "\n")
    end
  end
end

if not have_plugin then
  io.stderr:write("[lumen] no LuaTools plugin backend present; running settings-menu only\n")
end

-- Millennium called on_load after requiring the plugin; we do the same so
-- inject_webkit_files() enqueues the frontend assets and the boot-time InitApis
-- runs. Only meaningful when the plugin backend is present.
if have_plugin and type(lifecycle) == "table" and type(lifecycle.on_load) == "function" then
  local ok, err = pcall(lifecycle.on_load)
  if not ok then io.stderr:write("[lumen] on_load error: " .. tostring(err) .. "\n") end
end

-- Dispatch registry: the plugin endpoints the frontend calls via
-- callServerMethod. Only populated when the plugin backend loaded; in no-plugin
-- mode the registry holds just Lumen's native menu RPCs (registered below).
local registry = {}
if have_plugin then
local ALLOWLIST = {
  "AddCustomApi","ApplyGameFix","ApplySettingsChanges","ApplySpaceFix",
  "CancelAddViaLuaTools","CancelLuaToolsAutoFix",
  "CancelGameDraft","CommitGameDraft",
  "CancelApplyFix","CheckApisForApp","CheckForFixes","CheckForUpdatesNow",
  "DeleteLuaToolsForApp","DismissLoadedApps","FetchFreeApisNow",
  "GetAddViaLuaToolsStatus","GetAllApis","GetApiList","GetApplyFixStatus",
  "GetFixLaunchOptions","GetHubcapStats","GetProtonDBStatus",
  "GetGameDraftStatus","EnrichGameImportFromDraft",
  "GetGameInstallPath","GetGamesDatabase","GetIconDataUrl","GetInitApisMessage",
  "GetInstalledFixes","GetInstalledLuaScripts","GetMorrenusStats",
  "GetSettingsConfig","GetThemes","GetTranslations","GetUnfixStatus",
  "HasLuaToolsForApp","IsCompatToolForced","Logger.log",
  "OpenExternalUrl","OpenGameFolder","ReadLoadedApps","ResolveOnlineFix",
  "RemoveApi","RenameApi","ReorderApis","RestartSteam","ToggleApi","UnFixGame",
  "SearchSteamGames","GetSteamAppDetails","StartAddViaLuaTools",
  "StartAddViaLuaToolsFromUrl","StartAddViaLuaToolsSmart",
  "StartAddViaLuaToolsSource","StartGameDraft",
  "GetGameUpdates","SetGamePin","SetDlcPin","ClearGamePin","ClearDlcPin",
  "DeleteManifest","ClearManifests",
  "GetLuaToolsAuthStatus","LoginLuaToolsWithCode","StartLuaToolsDiscordLogin",
  "PollLuaToolsDiscordLogin","CancelLuaToolsDiscordLogin","LogoutLuaTools",
  "AdoptLuaToolsSessionValue",
  "GetLuaToolsFixesCatalogue","GetLuaToolsFixesForGame","GetLuaToolsAddRecommendation",
  "StartLuaToolsRecommendedAdd","StartLuaToolsFix",
  "CompleteLuaToolsFixApply",
}

-- New LuaTools builds publish their explicit public surface with the lifecycle
-- table. That keeps the security property of an allowlist without duplicating
-- the contract across two repositories (the duplication is what made valid new
-- calls fail as "unknown method"). Keep the local list only for plugin builds
-- from before the contract existed.
local rpc_methods = type(lifecycle) == "table"
  and type(lifecycle.rpc_methods) == "table"
  and lifecycle.rpc_methods or ALLOWLIST

for _, name in ipairs(rpc_methods) do
  if type(_G[name]) == "function" then
    registry[name] = _G[name]
  else
    io.stderr:write("[lumen] WARN: allowlisted endpoint missing: " .. name .. "\n")
  end
end
-- The selected list is the whole contract. There used to be a "safety net" here that
-- additionally exposed every PascalCase global the backend happened to define,
-- so any new helper function in main.lua silently became a callable endpoint —
-- the opposite of an allowlist. Current plugins add reviewed endpoints to their
-- rpc_contract.lua; ALLOWLIST above is only the compatibility surface for plugin
-- builds that predate that contract.
end

-- Frontend assets: the millennium shim queued relative paths (e.g.
-- "webkit/luatools.js") during inject_webkit_files; the files live in the
-- plugin's public/ dir (sibling of backend/). Read them for injection.
local millennium = require("millennium")
local utils = require("utils")
local polyfill = require("polyfill")
local plugin_dir = backend:gsub("/backend$", "")

local function read_asset(rel)
  local base = rel:gsub("^webkit/", "")
  return utils.read_file(plugin_dir .. "/public/" .. base)
end

-- build_assets() -> { polyfill=true, css={...}, js={...} }
-- `polyfill = true` asks the injector to emit the callServerMethod polyfill for
-- this channel. The injector builds it per connection because it carries that
-- connection's random binding token, so it cannot be pre-rendered here.
local function build_assets()
  local css, js = {}, {}
  for _, p in ipairs(millennium.queued_css()) do
    local c = read_asset(p); if c then css[#css + 1] = c end
  end
  for _, p in ipairs(millennium.queued_js()) do
    local j = read_asset(p); if j then js[#js + 1] = j end
  end
  return { polyfill = true, css = css, js = js }
end

-- The Lumen settings menu (the full-moon button + settings overlay) is a small,
-- well-behaved script injected into the main client shell (SharedJSContext) —
-- NOT luatools.js, which must never go there (see the channel split below). It
-- talks to the same backend via the same binding polyfill. Register its two
-- native RPCs (read/write slsteam-moon's config.yaml) into the dispatch table.
local slsconfig = require("slsconfig")
local slsconfig_path = slsconfig.default_path()
local parental_unlock_enabled = false
local webview_assets
local offers_assets

-- Special Offers is an authenticated marketing popup, not a normal Store
-- webview. Keep it out of the LuaTools/menu bundle and remove only Steam's
-- parental form when the user explicitly enabled the local parental unlock.
local SPECIAL_OFFERS_UNLOCK_JS = [[
(function(){
  if(window.__lumenOffersUnlock)return;
  window.__lumenOffersUnlock=true;
  if(location.hostname!=="store.steampowered.com"||
      !/^\/marketingmessages\/list\/?$/.test(location.pathname))return;
  function unlock(){
    var menu=document.querySelector('[data-featuretarget="store-menu-v7"]');
    if(menu){
      menu.style.setProperty("display","none","important");
      menu.setAttribute("aria-hidden","true");
    }
    var root=document.getElementById("main_content");
    if(!root)return;
    var forms=root.querySelectorAll("form");
    for(var i=0;i<forms.length;i++){
      var form=forms[i], text=(form.textContent||"").replace(/\s+/g," ");
      if(text.indexOf("Family View")!==-1&&
          text.indexOf("Request Access")!==-1){
        form.style.setProperty("display","none","important");
        form.setAttribute("aria-hidden","true");
      }
    }
  }
  unlock();
  new MutationObserver(unlock).observe(document.documentElement,
    {childList:true,subtree:true});
})();
]]

local function refresh_parental_unlock(values)
  values = values or slsconfig.read(slsconfig_path)
  parental_unlock_enabled =
    values.DisableParentalRestrictions == true
  if webview_assets then
    webview_assets.anonymous_web = parental_unlock_enabled
  end
  if offers_assets then
    offers_assets.js = parental_unlock_enabled
      and { SPECIAL_OFFERS_UNLOCK_JS } or {}
  end
end

refresh_parental_unlock()
require("slsmenu").register(registry, {
  path = slsconfig_path,
  on_values = refresh_parental_unlock,
})

-- The "Game Updates" tab (manifest pinning): assemble the per-game version
-- tree from on-disk data and read/write the ManifestPins map in config.yaml.
require("manifestpins").register(registry)

-- The "About" tab: report installed-vs-latest versions of the stack components
-- (from the release tags) and open a terminal for "Update All". In no-plugin
-- mode the plugin row is dropped and Update All re-runs the installer with
-- --noplugin so an update never re-adds the plugin.
require("about").register(registry, { no_plugin = not have_plugin })

-- The library-page "Fixes Menu" (menu/10-fixes-menu.js): one context RPC
-- (install path + name + Proton-effective) so the menu can reuse the existing
-- LuaTools fix RPCs on a game's library page.
require("fixesmenu").register(registry)

-- The "slsteam-moon not loaded" warning (menu/13-sls-check.js): detect whether
-- SLSsteam.so is actually injected into the running Steam client, and if not,
-- offer an auto-fix that re-installs the latest slsteam-moon, repairs the
-- *steam*.desktop launchers and relaunches Steam injected. Always registered
-- (the check is a cheap /proc scan; it's meaningful in every mode).
require("slscheck").register(registry)

-- Native restart is always available, including --noplugin installs. Register
-- after collecting plugin endpoints so the safe slsteam-moon-aware helper
-- replaces any plugin-provided RestartSteam implementation.
require("steamrestart").register(registry)

-- The "Cloud Saves" tab (menu/12-cloud-tab.js): set up CloudRedirect cloud
-- saves (provider, OAuth sign-in, stats toggles) directly against the hook's
-- ~/.config/CloudRedirect file contract — no flatpak, no background process.
-- Gated on CloudRedirect actually being installed (its .so on disk): without
-- it there's nothing to configure, so we DON'T register the cloud RPCs and the
-- menu hides the tab (window.__lumenCloud=false) — zero cost for users who
-- don't use cloud saves. Single file-stat, decided once here at boot.
local have_cloudredirect = slsconfig.has_cloudredirect()
if have_cloudredirect then
  require("cloudsettings").register(registry)
end

local lua_dir = os.getenv("LUMEN_LUA_DIR") or "lua"
local gamepad_toast_js = utils.read_file(lua_dir .. "/gamepad-toasts.js")
if not gamepad_toast_js then
  io.stderr:write("[lumen] WARN: gamepad toast bridge not found\n")
end
local auto_fix_launch_guard_js = utils.read_file(
  lua_dir .. "/auto-fix-launch-guard.js")
if not auto_fix_launch_guard_js then
  io.stderr:write("[lumen] WARN: auto-fix launch guard not found\n")
end

-- The Lumen settings menu used to be one ~1.2k-line lumen_menu.js. It's now
-- split into ordered source fragments under menu/ (one concern per file) for
-- maintainability. They share a SINGLE closure (idempotency guard + private
-- state), so they must be injected as one unit: we concatenate them in order
-- into one string and inject that with a single Runtime.evaluate. The assembled
-- output is behaviourally identical to the old single file. ORDER MATTERS:
-- 01-core opens the IIFE; 11-menubar runs the bootstrap and closes it. The
-- fixes-menu fragment (10) must come BEFORE 11-menubar (the IIFE closer).
local MENU_PARTS = {
  "01-core.js", "02-i18n.js", "03-styles.js", "04-overlay-helpers.js",
  "05-config-tab.js", "06-updates-helpers.js", "07-updates-tab.js",
  "08-about-tab.js", "09-luatools-account.js", "09-overlay.js",
  "10-auto-fix-status.js", "10-fixes-menu.js", "12-cloud-tab.js",
  "13-sls-check.js", "11-menubar.js",
}

local function read_menu_js()
  local parts = {}
  for _, name in ipairs(MENU_PARTS) do
    local chunk = utils.read_file(lua_dir .. "/menu/" .. name)
    if not chunk then
      io.stderr:write("[lumen] WARN: menu fragment not found: menu/" .. name .. "\n")
      return nil
    end
    parts[#parts + 1] = chunk
  end
  -- Tell the menu whether the LuaTools plugin is present. The fragments read
  -- window.__lumenNoPlugin to drop plugin-only UI (the About-tab plugin row and
  -- the Game Updates source-import path) in a --noplugin install. Set as a
  -- separate statement BEFORE the menu IIFE so it's in scope when the IIFE runs.
  local prefix = "window.__lumenNoPlugin=" .. (have_plugin and "false" or "true") .. ";\n"
    .. "window.__lumenCloud=" .. (have_cloudredirect and "true" or "false") .. ";\n"
  return prefix .. table.concat(parts, "\n")
end

-- build_menu_assets() -> assets for the visible Steam shell: polyfill +
-- lumen_menu.js (the full-moon button + settings overlay).
local function build_menu_assets()
  local js = {}
  local menu_js = read_menu_js()
  if menu_js then js[#js + 1] = menu_js end
  return { polyfill = true, css = {}, js = js }
end

-- build_webview_assets() -> the store/community bundle: the LuaTools webkit
-- frontend PLUS lumen_menu.js. The menu script is injected here too (in addition
-- to the main window) so the settings overlay can render natively inside the web
-- view that's on top — store/community views composite ABOVE the main-window
-- DOM, so an overlay in the main window alone would be hidden behind them and
-- couldn't receive input. lumen_menu.js adds no menubar button here (there's no
-- menubar in a web view); it only exposes window.__lumenOpenOverlay so the
-- sidecar can open/close it on demand. See injector State:broadcast_overlay.
local function build_webview_assets()
  local base = build_assets()
  local menu_js = read_menu_js()
  if menu_js then base.js[#base.js + 1] = menu_js end
  return base
end

local loop = require("loop")
-- NOTE: the once-per-session desktop-coverage heal is NOT run here any more.
-- Starting it at Lumen boot put a 2.9-3.9 s shell pass into the most
-- CPU-contended second of Steam's launch — a second one, since the wrapper
-- already kicks the guardian for the same work — and measurably delayed Steam
-- becoming usable on a 4-core box. loop.run() now runs it once, ~45 s after
-- boot (deskcover.new_initial), and the guardian .path/.timer units plus the
-- loop's autostart watch keep covering drift in the meantime.
-- Injection channels:
--   * web views (store/community)  -> luatools.js + lumen_menu.js
--   * the visible DESKTOP shell -> lumen_menu.js (menubar button next to Help)
-- Gamepad UI gets no menu bundle on purpose: its shell ("Steam Big Picture
-- Mode") matches no channel, so Game Mode keeps only the store web view.
-- The native menubar (Steam/View/Friends/Games/Help) lives in the main window
-- target titled "Steam". luatools.js must NEVER reach the main window: it
-- monkey-patches history.pushState, observes document.body and runs periodic
-- DOM scans the React shell never expects, which breaks the menubar. The
-- lumen_menu.js bundle is deliberately minimal and shell-safe. The menubar
-- button broadcasts open/close to every context so the overlay renders in
-- whichever view is currently on top (see injector State:broadcast_overlay).
webview_assets = build_webview_assets()
webview_assets.anonymous_web = parental_unlock_enabled
offers_assets = {
  css = {},
  js = parental_unlock_enabled and { SPECIAL_OFFERS_UNLOCK_JS } or {},
}
local notifyqueue = require("notifyqueue")
local plugin_tick = require("plugintick").new(lifecycle, { interval = 5 })
local next_notify_poll = 0
loop.run({
  registry = registry,
  on_steam_returned = refresh_parental_unlock,
  channels = {
    { origins = { { host = "store.steampowered.com",
                    path_prefix = "/marketingmessages/list" } },
      remote = true, assets = offers_assets },
    { origins = { { host = "store.steampowered.com" },
                  { host = "steamcommunity.com" } },
      remote = true, assets = webview_assets },
    { titles = { ["Steam"] = true }, assets = build_menu_assets() },
    -- Control link to the only context with SteamClient. The tiny toast bridge
    -- also renders queued service alerts inside Gamepad UI.
    { titles = { ["SharedJSContext"] = true }, control = true,
      assets = { polyfill = nil, css = {},
        js = {
          gamepad_toast_js,
          auto_fix_launch_guard_js,
        } } },
  },
  on_tick = function(inj, now)
    local plugin_result = plugin_tick:run(now, inj)
    if type(plugin_result) == "table" and plugin_result.success == false then
      io.stderr:write("[lumen] plugin background tick failed: "
        .. tostring(plugin_result.error or plugin_result.errorCode or "unknown") .. "\n")
    end
    if now < next_notify_poll then return end
    next_notify_poll = now + 0.25
    local events = notifyqueue.drain()
    if not inj:is_gamepad_ui() then return end
    for _, event in ipairs(events) do inj:show_gamepad_toast(event) end
  end,
})
